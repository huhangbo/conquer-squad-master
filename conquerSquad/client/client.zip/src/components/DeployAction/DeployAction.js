import styles from "./DeployAction.less";

export default function DeployAction() {
    return (
        <div className={styles.action}>
            铸造
        </div>
    )
}
