import styles from "./Instruction.less"

export default function Instruction () {
    return (
        <div className={styles.instruction}>
            <div className={styles.content}>

            </div>
        </div>
    )
}
