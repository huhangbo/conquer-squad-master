export function sliceId (id) {
    return  `${id.substr(0, 6)}...${id.substr(-4)}`
}
